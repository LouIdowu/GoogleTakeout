# GoogleTakeout
Python scripts to analyze YouTube watch history data, utilizing NLP, LDA, and data visualization tools for insights.
